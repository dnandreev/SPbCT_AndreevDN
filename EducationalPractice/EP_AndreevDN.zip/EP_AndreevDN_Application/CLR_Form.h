﻿#pragma once
#pragma comment(lib, "netapi32.lib") //Необходимо для создания учётной записи пользователя
#pragma comment(lib, "User32.lib")   //Необходимо для MessageBoxW
#include "Lib.h"                     //Статическая библиотека, содержащая функции получения текущих даты и времени
#include "vector.h"                  //Содержит класс "вектор" символов типа wchar_t
#include <Windows.h>                 //Необходимо для операций с параллельными потоками и процессами, файлами и каналами
#include <LM.h>                      //Необходимо для создания учётной записи пользователя
#include <vcclr.h>                   //Необходимо для PtrToStringChars
#include <fstream>                   //Необходимо для операций с файлами
#include <algorithm>                 //Необходимо для сортировки вектора строк типа wstring
#include <vector>                    //Необходимо для организации вектора строк типа wstring
using namespace std;

bool fileOpened = false, sortingStarted = false; //Флаги начала чтения из текстового файла и начала сортировки его содержимого
Vector text, copies[10], results[10]; //Векторы символов типа wchar_t
int index = 0; //Переменная для назначения индексов потокам, выполняющим параллельную сортировку содержимого подстрок файла
HANDLE mutexIndex; //Мьютекс для безопасного назначения индексов потокам

DWORD WINAPI Sorter(LPVOID lpParam) { //Поток, выполняющий сортировку содержимого подстроки файла
	if (WaitForSingleObject(mutexIndex, INFINITE) != 0) { //Если не получилось дождаться освобождения мьютекса
		MessageBoxW(NULL, L"Не удалось начать сортировать содержимое текстового файла.", L"Ошибка!", MB_OK | MB_ICONERROR); //Вывести сообщение об ошибке
		return 0; //И завершить поток
	}
	else { //Иначе
		int myIndex = index++; //Назначить себе индекс, увеличив переменную для назначения индексов на 1
		ReleaseMutex(mutexIndex); //Освободить мьютекс
		copies[myIndex] = *(new Vector); //Создать вектор символов для копии подстроки файла
		results[myIndex] = *(new Vector); //Создать вектор символов для отсортированной по возрастанию подстроки файла
		for (int i = 0; i < 10; i++) { //Установить достаточную длину созданных векторов символов
			copies[myIndex].Insert(i + 1); //Прирастить к вектору для копии подстроки 1 символ
			results[myIndex].Insert(i + 1); //Прирастить к вектору для отсортированной подстроки 1 символ
			copies[myIndex].operator[](i) = text[myIndex * 10 + i]; //Скопировать элемент подстроки
		}
		for (int i = 0; i < 10; i++) {//Отсортировать подстроку по возрастанию
			int iMin = 0; //Предположить, что наименьший по порядку символ подстроки - нулевой
			for (int j = 0; j < 10 - i; j++) //Попытаться найти более меньший по порядку символ подстроки
				if (copies[myIndex].operator[](j) < copies[myIndex].operator[](iMin)) //Если перебираемый символ подстроки меньше ранее наименьшего
					iMin = j; //Считать наименьшим перебираемый символ
			results[myIndex].operator[](i) = copies[myIndex].operator[](iMin); //Поместить наименьший символ подстроки на конец вектора символов для отсортированной по возрастанию подстроки файла
			copies[myIndex].Delete(iMin); //Удалить наименьший символ вектора символов для копии подстроки файла
		}
		return 1;
	}
}

namespace EPAndreevDNApplication {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for CLR_Form
	/// </summary>
	public ref class CLR_Form : public System::Windows::Forms::Form
	{
	public:
		CLR_Form(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~CLR_Form()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::GroupBox^ groupBox1;
	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Timer^ timer1;
	private: System::Windows::Forms::GroupBox^ groupBox2;
	private: System::Windows::Forms::TextBox^ textBox4;
	private: System::Windows::Forms::TextBox^ textBox3;



	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::GroupBox^ groupBox3;
	private: System::Windows::Forms::TextBox^ textBox5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::TextBox^ textBox6;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button4;
	private: System::ComponentModel::IContainer^ components;
	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(6, 16);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(373, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Автор программы: Андреев Дмитрий Николаевич, студент группы К590";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Controls->Add(this->textBox2);
			this->groupBox1->Controls->Add(this->label3);
			this->groupBox1->Controls->Add(this->textBox1);
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Enabled = false;
			this->groupBox1->Location = System::Drawing::Point(12, 12);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(385, 87);
			this->groupBox1->TabIndex = 1;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Сведения";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(6, 58);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(373, 23);
			this->button1->TabIndex = 3;
			this->button1->Text = L"Узнать текущее системное время";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &CLR_Form::button1_Click);
			// 
			// textBox2
			// 
			this->textBox2->Enabled = false;
			this->textBox2->Location = System::Drawing::Point(287, 32);
			this->textBox2->Name = L"textBox2";
			this->textBox2->ReadOnly = true;
			this->textBox2->Size = System::Drawing::Size(92, 20);
			this->textBox2->TabIndex = 4;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(191, 35);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(90, 13);
			this->label3->TabIndex = 3;
			this->label3->Text = L"Текущее время:";
			// 
			// textBox1
			// 
			this->textBox1->Enabled = false;
			this->textBox1->Location = System::Drawing::Point(93, 32);
			this->textBox1->Name = L"textBox1";
			this->textBox1->ReadOnly = true;
			this->textBox1->Size = System::Drawing::Size(92, 20);
			this->textBox1->TabIndex = 2;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(6, 35);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(81, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Текущая дата:";
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(6, 282);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(373, 23);
			this->button4->TabIndex = 5;
			this->button4->Text = L"Отсортировать содержимое текстового файла";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &CLR_Form::button4_Click);
			// 
			// timer1
			// 
			this->timer1->Enabled = true;
			this->timer1->Interval = 1000;
			this->timer1->Tick += gcnew System::EventHandler(this, &CLR_Form::timer1_Tick);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->textBox4);
			this->groupBox2->Controls->Add(this->textBox3);
			this->groupBox2->Controls->Add(this->button2);
			this->groupBox2->Controls->Add(this->label5);
			this->groupBox2->Controls->Add(this->label4);
			this->groupBox2->Location = System::Drawing::Point(12, 105);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(385, 100);
			this->groupBox2->TabIndex = 2;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Для добавления учётной записи пользователя введите";
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(60, 45);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(319, 20);
			this->textBox4->TabIndex = 4;
			this->textBox4->UseSystemPasswordChar = true;
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(60, 19);
			this->textBox3->MaxLength = 20;
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(319, 20);
			this->textBox3->TabIndex = 3;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(6, 71);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(373, 23);
			this->button2->TabIndex = 4;
			this->button2->Text = L"И нажмите эту кнопку";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &CLR_Form::button2_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(6, 48);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(48, 13);
			this->label5->TabIndex = 1;
			this->label5->Text = L"Пароль:";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(22, 22);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(32, 13);
			this->label4->TabIndex = 0;
			this->label4->Text = L"Имя:";
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->button4);
			this->groupBox3->Controls->Add(this->button3);
			this->groupBox3->Controls->Add(this->textBox6);
			this->groupBox3->Controls->Add(this->label7);
			this->groupBox3->Controls->Add(this->textBox5);
			this->groupBox3->Controls->Add(this->label6);
			this->groupBox3->Enabled = false;
			this->groupBox3->Location = System::Drawing::Point(12, 211);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(385, 311);
			this->groupBox3->TabIndex = 3;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"Сортировка текстового файла";
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(6, 97);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(373, 23);
			this->button3->TabIndex = 5;
			this->button3->Text = L"Вывести изначальное содержимое текстового файла";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &CLR_Form::button3_Click);
			// 
			// textBox6
			// 
			this->textBox6->Location = System::Drawing::Point(6, 139);
			this->textBox6->MaxLength = 118;
			this->textBox6->Multiline = true;
			this->textBox6->Name = L"textBox6";
			this->textBox6->ReadOnly = true;
			this->textBox6->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->textBox6->Size = System::Drawing::Size(373, 137);
			this->textBox6->TabIndex = 3;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(6, 123);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(262, 13);
			this->label7->TabIndex = 2;
			this->label7->Text = L"Отсортированное содержимое текстового файла:";
			// 
			// textBox5
			// 
			this->textBox5->Location = System::Drawing::Point(6, 32);
			this->textBox5->MaxLength = 100;
			this->textBox5->Multiline = true;
			this->textBox5->Name = L"textBox5";
			this->textBox5->ReadOnly = true;
			this->textBox5->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->textBox5->Size = System::Drawing::Size(373, 59);
			this->textBox5->TabIndex = 1;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(6, 16);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(239, 13);
			this->label6->TabIndex = 0;
			this->label6->Text = L"Изначальное содержимое текстового файла:";
			// 
			// CLR_Form
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(409, 534);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->Name = L"CLR_Form";
			this->Text = L"Программа по учебной практике";
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void timer1_Tick(System::Object^ sender, System::EventArgs^ e) { //Каждый такт таймера, то есть раз в секунду
		textBox1->Text = gcnew String(GetDate().c_str()); //Выводить текущую дату
		textBox2->Text = gcnew String(GetTime().c_str()); //Выводить текущее время
	}

private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) { //При нажатии на кнопку с надписью "узнать текущее системное время"
	HANDLE reader, writer; //Объявить дескрипторы концов канала
	SECURITY_ATTRIBUTES SA = { sizeof(SECURITY_ATTRIBUTES), NULL, TRUE }; //Создать атрибуты безопасности, позволяющие подпроцессам наследовать дескрипторы
	if (CreatePipe(&reader, &writer, &SA, 0) == FALSE) //Если не удалось создать канал для связи процессов
		MessageBox::Show(L"Не удалось создать канал между процессами.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error); //Вывести сообщение об этом
	else { //Иначе
		STARTUPINFO SI = {}; //Объявить пустую структуру, необходимую в данному случае для перенаправления вывода подпроцесса в канал
		SI.cb = sizeof(STARTUPINFO); //Необходимое значение
		SI.dwFlags = STARTF_USESTDHANDLES; //Использовать перенаправление вывода в указанные источники
		SI.hStdError = writer; //Перенаправить вывод ошибок в созданный канал
		SI.hStdOutput = writer; //Перенаправить вывод в созданный канал
		PROCESS_INFORMATION PI = {}; //Объявить пустую структуру, в которую поместятся дескрипторы созданного подпроцесса
		if (CreateProcess(L"C:\\Windows\\System32\\cmd.exe", L"C:\\Windows\\System32\\cmd.exe /c time /t", NULL, NULL, TRUE, NULL, NULL, NULL, &SI, &PI) == FALSE) { //Если не удалось создать подпроцесс - командную строку, выполняющую команду "time /t"
			MessageBox::Show(L"Не удалось создать дочерний процесс.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error); //Вывести сообщение об этом
			CloseHandle(writer); //Закрыть дескриптор записи в канал
			CloseHandle(reader); //Закрыть дескриптор чтения из канала
		}
		else { //Иначе
			CloseHandle(writer); //Закрыть дескриптор записи в канал
			char buf[1024 + 1] = {}; //Создать буфер минимального размера, подходящего для получения данных из подпроцесса командной строки
			DWORD read; //Переменная для сохранения количества прочитанных элементов
			BOOL Status = ReadFile(reader, buf, 1024, &read, NULL); //Считать из канала строку
			buf[read] = '\0'; //Поместить на конец считанной строки символ окончания строки
			String^ answer = gcnew String(buf); //Перевести считанную строку в тип, подходящий для среды CLR
			MessageBox::Show(answer, L"Результат команды time /t:", MessageBoxButtons::OK, MessageBoxIcon::Information); //Вывести сообщение с результатом команды
			CloseHandle(reader); //Закрыть дескриптор чтения из канала
			CloseHandle(PI.hProcess); //Закрыть дескриптор подпроцесса
			CloseHandle(PI.hThread); //Закрыть дескриптор потока подпроцесса
		}
	}
}

private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) { //При нажатии на кнопку создания учётной записи пользователя
	if (textBox3->Text->Length == 0) //Если имя учётной записи пользователя не было введено
		MessageBox::Show(L"Введите имя учётной записи пользователя.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error); //Вывести сообщение об этом
	else { //Иначе
		pin_ptr<const wchar_t> name = PtrToStringChars(textBox3->Text); //Перевести введённое имя учётной записи пользователя в другой тип данных
		pin_ptr<const wchar_t> password = PtrToStringChars(textBox4->Text); //Перевести введённый пароль учётной записи пользователя в другой тип данных
		_USER_INFO_1 UI1; //Объявить структуру, необходимую для создания учётной записи пользователя
		UI1.usri1_name = (LPWSTR)name; //Поместить в неё введённое имя
		if (textBox4->Text->Length == 0) //Если пароль не был введён
			UI1.usri1_password = NULL; //Задать пустой пароль
		else { //Иначе
			UI1.usri1_password = (LPWSTR)password; //Поместить в структуру введённый пароль
		}
		UI1.usri1_password_age = NULL; //Необходимое значение
		UI1.usri1_priv = USER_PRIV_USER; //Стандартный уровень привилегий
		UI1.usri1_home_dir = (LPWSTR)name; //Установить каталог учётной записи пользователя равным имени учётной записи пользователя
		UI1.usri1_comment = NULL; //Без комментариев к учётной записи пользователя
		UI1.usri1_flags = UF_SCRIPT | UF_HOMEDIR_REQUIRED | UF_DONT_REQUIRE_PREAUTH | UF_NORMAL_ACCOUNT; //Необходимые атрибуты учётной записи пользователя
		if (textBox4->Text->Length == 0) //Если пароль не был введён
			UI1.usri1_flags |= UF_PASSWD_NOTREQD; //Установить флаг "не требуется пароль"
		else //Иначе
			UI1.usri1_flags |= UF_DONT_EXPIRE_PASSWD; //Установить флаг "срок действия пароля не истекает"
		UI1.usri1_script_path = NULL; //Не выполнять скриптов при входе пользователя
		NET_API_STATUS status = NetUserAdd(NULL, 1, (LPBYTE)&UI1, NULL); //Добавить пользователя
		switch (status) { //Если ответ один из следующих, то вывести соответствующее сообщение
		case NERR_Success: {
			MessageBox::Show(L"Учётная запись пользователя успешно создана.", L"Успех!", MessageBoxButtons::OK, MessageBoxIcon::Information);
			groupBox1->Enabled = true; //Разблокировать контейнер элементов интерфейса "сведениям"
			groupBox2->Enabled = false; //Заблокировать контейнер элементов интерфейса "добавление учётной записи пользователя"
			groupBox3->Enabled = true; //Разблокировать контейнер элементов интерфейса "сортировка текстового файла"
			break;
		}
		case ERROR_ACCESS_DENIED: {
			MessageBox::Show(L"Доступ запрещён.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error);
			break;
		}
		case NERR_InvalidComputer: {
			MessageBox::Show(L"Неправильное имя компьютера.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error);
			break;
		}
		case NERR_UserExists: {
			MessageBox::Show(L"Учётная запись пользователя уже существует.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error);
			break;
		}
		case NERR_PasswordTooShort: {
			MessageBox::Show(L"Введите другой пароль.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error);
			break;
		}
		default:
			MessageBox::Show(L"Неизвестная ошибка.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error);
			break;
		}
	}
}

private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) { //При нажатии на кнопку с надписью "вывести изначальное содержимое текстового файла"
	FILE* f; //Объявить дескриптор файла
	_wfopen_s(&f, L"file_in.txt", L"rt, ccs=UTF-8"); //Открыть файл для чтения в текстовом режиме и с кодировкой UTF-8
	if (f == NULL) //Если не удалось открыть файл
		MessageBox::Show(L"Не удалось открыть файл \"file_in.txt\".", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error); //Вывести сообщение об этом
	else { //Иначе
		struct _stat fileinfo; //Объявить пустую структуру, в которую поместится информация об открытом файле
		_wstat(L"file_in.txt", &fileinfo); //Считать информацию об открытом файле в объявленную структуру
		if (fileinfo.st_size != 200) //Если размер файла не равен 200 байт
			MessageBox::Show(L"В файле \"file_in.txt\" должно быть 100 символов кириллицы.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error); //Вывести сообщение об этом
		else { //Иначе
			if (fileOpened == false) { //Если чтение текстового файла не было начато
				fileOpened = true; //Установить флаг начала чтения из текстового файла
				for (int i = 0; i < 100; i++) { //Считать 100 символов размером по 2 байта в вектор символов типа wchar_t
					text.Insert(i + 1); //Прирастить к вектору 1 элемент
					fread_s(&text[i], sizeof(wchar_t), sizeof(wchar_t), 1, f); //Считать 1 символ в приращённый к вектору элемент
				}
				text[100] = '\0'; //Поместить на конец считанной строки символ окончания строки
				String^ S = gcnew String(L""); //Объявить строку, подходящую для среды CLR
				for (int i = 0; i <= 100; i++) //Перевести считанную строку в тип, подходящий для среды CLR
					S += text[i]; //Приращивать к строке, подходящей для среды CLR, по одному символу
				textBox5->Text = S; //Вывести считанный из файла текст в текстовое поле в окне программы
			}
		}
	}
	fclose(f); //Закрыть дескриптор файла
}

private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) { //При нажатии на кнопку "отсортировать содержимое текстового файла"
	if (sortingStarted == false) { //Если сортировка содержимого текстового файла не была начата
		if (fileOpened == false) //Если чтение текстового файла не было начато
			MessageBox::Show(L"Сначала нажмите предыдущую кнопку.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error); //Вывести сообщение об этом
		else { //Иначе
			sortingStarted = true; //Установить флаг начала сортировки содержимого текстового файла
			mutexIndex = CreateMutex(NULL, TRUE, NULL); //Создать мьютекс для безопасного назначения индексов потокам
			HANDLE Threads[10]; //Создать массив дескрипторов потоков
			for (int i = 0; i <= 9; i++) //Создать 10 параллельных потоков
				if ((Threads[i] = CreateThread(NULL, NULL, Sorter, NULL, NULL, NULL)) == 0) { //Если не удалось создать поток
					MessageBox::Show(L"Не удалось создать поток.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error); //Вывести сообщение об этом
					break; //Прекратить создание потоков
				}
				else { //Иначе
					ReleaseMutex(mutexIndex); //Освободить мьютекс
					WaitForMultipleObjects(10, Threads, TRUE, INFINITE); //Дождаться завершения работы созданных потоков
					DWORD ExitCode; //Объявить переменную, в которую будут помещаться коды завершения потоков
					int Bads = 0; //Счётчик неудачных завершений потоков
					for (int i = 0; i < 10; i++) { //Получить коды завершения созданных потоков
						GetExitCodeThread(Threads[i], &ExitCode);
						if (ExitCode == 0) { //Если код завершения потока неудачен
							Bads++; //Увеличить счётчик неудачных завершений потоков на 1
							break; //И выйти из цикла
						}
					}
					if (Bads > 0) //Если есть неудачные завершения работы потоков
						MessageBox::Show(L"Не удалось отсортировать содержимое текстового файла.", L"Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error); //Вывести сообщение об этом
					else { //Иначе
						vector <wstring> ss; //Объявить вектор строк типа wstring
						for (int i = 0; i <= 9; i++) { //Поместить в объявленный вектор 10 строк типа wstring
							wchar_t wtemp[11]; //Объявить массив символов типа wchar_t
							wtemp[10] = '\0'; //Завершить объявленный массив символом окончания строки
							for (int j = 0; j <= 9; j++) //Наполнить объявленный массив символами отсортированной по возрастанию подстроки файла
								wtemp[j] = results[i].operator[](j);
							wstring ws(wtemp); //Создать строку типа wstring из массива символов типа wchar_t
							ss.push_back(ws); //Поместить созданную строку в вектор строк типа wstring
						}
						sort(ss.begin(), ss.end(), greater<wstring>()); //Произвести сортировку элементов вектора строк типа wstring по убыванию
						wchar_t res[119]; //Объявить массив символов типа wchar_t
						res[118] = '\0'; //Завершить объявленный массив символом окончания строки
						for (int i = 0; i <= 9; i++) { //Скопировать содержимое вектора строк типа wstring в массив символов типа wchar_t
							for (int j = 0; j <= 9; j++) //Скопировать подстроку
								res[i * 12 + j] = ss[i][j];
							if (i != 9) { //После всех строк, кроме последней, ставить переносы строк
								res[i * 12 + 10] = '\r';
								res[i * 12 + 11] = '\n';
							}
						}
						FILE* f; //Объявить дескриптор файла
						_wfopen_s(&f, L"file_out.txt", L"wb"); //Открыть файл для записи в двоичном режиме
						fwrite(res, sizeof(wchar_t), (sizeof(res) - sizeof(wchar_t)) / sizeof(wchar_t), f); //Записать в файл отсортированное содержимое текстового файла
						fflush(f); //Дождаться окончания записи данных в текстовый файл
						fclose(f); //Закрыть дескриптор файла
						String^ S = gcnew String(res); //Создать строку, подходящую для среды CLR, из массива символов типа wchar_t
						textBox6->Text = S; //Вывести отсортированное содержимое текстового файла в текстовое поле в окне программы
					}
				}
		}
	}
}
};
}