#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#ifdef LR20DLL_EXPORTS
#define LR20DLL_API __declspec(dllexport)
#else
#define LR20DLL_API __declspec(dllimport)
#endif

extern "C" LR20DLL_API double TrianglePerimeter(double s1, double a1, double a2);

extern "C" LR20DLL_API double TriangleSquare(double s1, double a1, double a2);