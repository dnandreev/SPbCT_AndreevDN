﻿#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h>
#include <errno.h> 
#include <sys/wait.h> 
int main(){
    int x = 2, pid;
    printf("Single process, x=%d\n", x);
    pid = fork();
    if(pid == 0){ // Потомок
        printf("New, x=%d\n",x);
    }
    else if(pid > 0){ // Родитель
        printf("Old, pid=%d, x=%d\n", pid, x);
        sleep(5);
        wait(&pid);
    }
    else{
        perror(" Fork error ");
        return -1;
    }
    return 0;
};