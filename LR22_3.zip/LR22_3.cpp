#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h>
#include <iostream>
#include <fstream>
using std::cout;
using std::endl;
int VAR = 1;
int main(){
    std::ofstream out("Output_processes.txt");
    cout << "\n Count of global variable: "<< VAR << "\n Count of global variable before fork: " << VAR+1 << endl;
    pid_t pid = fork();
    if (pid == 0){
        cout << "\n Count of global variable in Child process before increase: " << VAR << ", after: " << VAR+5 << endl;
    }
    else if(pid > 0){
        cout<< "\n Count of global variable in Parent process before increase: "<< VAR << ", after: " << VAR+3 <<endl;
        out << "Child process ID: " << getpid() <<"\n" << " Parent process ID: " << getppid();
    }
}