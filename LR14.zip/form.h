#pragma once
#include "matrix.h"
#include <fstream>
namespace LR14 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� form
	/// </summary>
	public ref class form : public System::Windows::Forms::Form
	{
	public:
		form(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~form()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::GroupBox^ groupBox1;
	private: System::Windows::Forms::CheckBox^ checkBox1;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ dataGridViewTextBoxColumn1;

	protected:

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->dataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->groupBox1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(12, 406);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(297, 23);
			this->button1->TabIndex = 1;
			this->button1->Text = L"��������� � ���� \"matrix.txt\"";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &form::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(315, 406);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(297, 23);
			this->button2->TabIndex = 2;
			this->button2->Text = L"��������� �� ����� \"matrix.txt\"";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &form::button2_Click);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->button4);
			this->groupBox1->Controls->Add(this->button3);
			this->groupBox1->Controls->Add(this->checkBox1);
			this->groupBox1->Controls->Add(this->dataGridView1);
			this->groupBox1->Location = System::Drawing::Point(12, 12);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(600, 388);
			this->groupBox1->TabIndex = 0;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"�������";
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(496, 359);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(98, 23);
			this->button4->TabIndex = 3;
			this->button4->Text = L"������ �������";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &form::button4_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(381, 359);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(109, 23);
			this->button3->TabIndex = 2;
			this->button3->Text = L"�������� �������";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &form::button3_Click);
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Checked = true;
			this->checkBox1->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox1->Location = System::Drawing::Point(6, 363);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(369, 17);
			this->checkBox1->TabIndex = 1;
			this->checkBox1->Text = L"������������� ��������� ��������� ������� � ������������ ����";
			this->checkBox1->UseVisualStyleBackColor = true;
			this->checkBox1->CheckedChanged += gcnew System::EventHandler(this, &form::checkBox1_CheckedChanged);
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToResizeColumns = false;
			this->dataGridView1->AllowUserToResizeRows = false;
			this->dataGridView1->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dataGridView1->AutoSizeRowsMode = System::Windows::Forms::DataGridViewAutoSizeRowsMode::AllCells;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->ColumnHeadersVisible = false;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) { this->dataGridViewTextBoxColumn1 });
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle1->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle1->Format = L"N";
			dataGridViewCellStyle1->NullValue = nullptr;
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->dataGridView1->DefaultCellStyle = dataGridViewCellStyle1;
			this->dataGridView1->Location = System::Drawing::Point(6, 19);
			this->dataGridView1->MultiSelect = false;
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersWidthSizeMode = System::Windows::Forms::DataGridViewRowHeadersWidthSizeMode::DisableResizing;
			this->dataGridView1->Size = System::Drawing::Size(588, 334);
			this->dataGridView1->TabIndex = 0;
			this->dataGridView1->CellEndEdit += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &form::dataGridView1_CellEndEdit);
			this->dataGridView1->EditingControlShowing += gcnew System::Windows::Forms::DataGridViewEditingControlShowingEventHandler(this, &form::dataGridView1_EditingControlShowing);
			this->dataGridView1->UserAddedRow += gcnew System::Windows::Forms::DataGridViewRowEventHandler(this, &form::dataGridView1_UserAddedRow);
			this->dataGridView1->UserDeletingRow += gcnew System::Windows::Forms::DataGridViewRowCancelEventHandler(this, &form::dataGridView1_UserDeletingRow);
			this->dataGridView1->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &form::dataGridView1_KeyPress);
			this->dataGridView1->Leave += gcnew System::EventHandler(this, &form::dataGridView1_Leave);
			// 
			// dataGridViewTextBoxColumn1
			// 
			this->dataGridViewTextBoxColumn1->Name = L"dataGridViewTextBoxColumn1";
			this->dataGridViewTextBoxColumn1->Width = 21;
			// 
			// form
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(624, 441);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->Name = L"form";
			this->ShowIcon = false;
			this->Text = L"�� �14";
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
MatrixTriangle* M = new MatrixTriangle();
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	M->InsertColumn(dataGridView1->ColumnCount);
	dataGridView1->ColumnCount++;
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	if (dataGridView1->ColumnCount > 1) {
		M->DeleteColumn(dataGridView1->ColumnCount - 1);
		dataGridView1->Columns->RemoveAt(dataGridView1->ColumnCount - 1);
	}
}
private: System::Void dataGridView1_Leave(System::Object^ sender, System::EventArgs^ e) {
	if ((checkBox1->Checked == true) && (M->TriangleTry() == true))
		for (int i = 0; i < M->LengthY - 1; i++)
			for (int j = 0; j < M->LengthX; j++)
				dataGridView1->Rows[i]->Cells[j]->Value = M->CellGet(j, i);
}
private: System::Void dataGridView1_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
	if (e->KeyChar == (Char)Keys::Escape)
		groupBox1->Focus();
}
Control^ editControl;
private: System::Void dataGridView1_EditingControlShowing(System::Object^ sender, System::Windows::Forms::DataGridViewEditingControlShowingEventArgs^ e) {
	editControl = e->Control;
	editControl->KeyPress += gcnew KeyPressEventHandler(this, &form::EditingControl_KeyPress); //������� �� ������� ����� �������� � ����������
}
private: System::Void EditingControl_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
	Char c = e->KeyChar;
	if (Char::IsControl(c))
		return;
	if ((c == '-') && (editControl->Text->Length == 0))
		return;
	if ((c == ',') && (editControl->Text->Contains(",") == false))
		return;
	if ((c >= '0') && (c <= '9'))
		return;
	e->Handled = true;
	//e->Handled = true �������� ����������
	//return �������� �������
}
private: System::Void dataGridView1_UserAddedRow(System::Object^ sender, System::Windows::Forms::DataGridViewRowEventArgs^ e) {
	M->InsertRow(e->Row->Index);
}
private: System::Void dataGridView1_UserDeletingRow(System::Object^ sender, System::Windows::Forms::DataGridViewRowCancelEventArgs^ e) {
	M->DeleteRow(e->Row->Index);
}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	M->FileSave("matrix.txt");
}
private: System::Void dataGridView1_CellEndEdit(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
	System::String^ s = dataGridView1->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value->ToString();
	if ((s == ",") || (s == "-") || (s == "-,"))
		MessageBox::Show("������ ������� �����������!");
	else {
		M->CellSet(e->ColumnIndex, e->RowIndex, Convert::ToDouble(s));
		if ((checkBox1->Checked == true) && (M->TriangleTry() == true))
			for (int i = 0; i < M->LengthY - 1; i++)
				for (int j = 0; j < M->LengthX; j++)
					dataGridView1->Rows[i]->Cells[j]->Value = M->CellGet(j, i);
	}
}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	M->FileLoad("matrix.txt");
	dataGridView1->Rows->Clear();
	int X = M->LengthX, Y = M->LengthY;
	dataGridView1->ColumnCount = X;
	dataGridView1->RowCount = Y;
	if (checkBox1->Checked == true)
		M->TriangleTry();
	for (int i = 0; i < Y - 1; i++)
		for (int j = 0; j < X; j++)
			dataGridView1->Rows[i]->Cells[j]->Value = M->CellGet(j, i);
}
private: System::Void checkBox1_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
	if ((checkBox1->Checked == true) && (M->TriangleTry() == true))
		for (int i = 0; i < M->LengthY - 1; i++)
			for (int j = 0; j < M->LengthX; j++)
				dataGridView1->Rows[i]->Cells[j]->Value = M->CellGet(j, i);
}
};
}