#define _CRT_SECURE_NO_WARNINGS
#include <Windows.h>
#include <malloc.h>
#include <stdio.h>
#define BUF_SIZE 256
using namespace std;

int main(DWORD argc, LPTSTR argv[]) {
	HANDLE hTempFile = 0;
	BOOL prov;
	TCHAR outFile[MAX_PATH + 100];
	SECURITY_ATTRIBUTES StdOutSA = { sizeof(SECURITY_ATTRIBUTES), 0, TRUE };
	TCHAR CommandLine[MAX_PATH + 100];
	STARTUPINFO StartUpSearch, StartUp;
	GetStartupInfo(&StartUpSearch);
	GetStartupInfo(&StartUp);
	PROCESS_INFORMATION ProcessInfo;
	DWORD iProc, ExCode;
	typedef struct { TCHAR TempFile[MAX_PATH]; } PROCFILE;
	PROCFILE* ProcFile = (PROCFILE*)malloc((argc - 2) * sizeof(PROCFILE));
	HANDLE* hProc = (HANDLE*)malloc((argc - 2) * sizeof(HANDLE));
	for (iProc = 0; iProc < argc - 2; iProc++) {
		sprintf((char*)CommandLine, "%s%s%s%s", "grep ", argv[1], " ", argv[iProc + 2]);
		printf("%s\n", CommandLine);
		if (GetTempFileName(L".", L"gtm", 0, ProcFile[iProc].TempFile) == 0)
			hTempFile = CreateFile(ProcFile[iProc].TempFile, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, &StdOutSA, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
		StartUpSearch.dwFlags = STARTF_USESTDHANDLES;
		StartUpSearch.hStdOutput = hTempFile;
		StartUpSearch.hStdError = hTempFile;
		StartUpSearch.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
		CreateProcess(0, CommandLine, 0, 0, TRUE, 0, 0, 0, &StartUpSearch, &ProcessInfo);
		CloseHandle(hTempFile);
		CloseHandle(ProcessInfo.hThread);
		hProc[iProc] = ProcessInfo.hProcess;
	}
	for (iProc = 0; iProc < argc - 2; iProc += MAXIMUM_WAIT_OBJECTS)
		WaitForMultipleObjects(min(MAXIMUM_WAIT_OBJECTS, argc - 2 - iProc), &hProc[iProc], TRUE, INFINITE);
	for (iProc = 0; iProc < argc - 2; iProc++) {
		printf("Proc=%d\n", iProc);
		prov = GetExitCodeProcess(hProc[iProc], &ExCode);
		if (ExCode != 0)
			DeleteFile(ProcFile[iProc].TempFile);
		if (GetExitCodeProcess(hProc[iProc], &ExCode) && ExCode == 0) {
			if (argc > 3)
				printf("%s:\n", argv[iProc + 2]);
			fflush(stdout);
			sprintf((char*)outFile, "%s", ProcFile[iProc].TempFile);
			CopyFile(argv[iProc + 2], (LPTSTR)outFile, FALSE);
			sprintf((char*)CommandLine, "%s%s", "cat ", ProcFile[iProc].TempFile);
			printf("%s\n", CommandLine);
			CreateProcess(0, CommandLine, 0, 0, TRUE, 0, 0, 0, &StartUp, &ProcessInfo);
			WaitForSingleObject(ProcessInfo.hProcess, INFINITE);
			CloseHandle(ProcessInfo.hProcess);
			CloseHandle(ProcessInfo.hThread);
		}
		CloseHandle(hProc[iProc]);
	}
	free(ProcFile);
	free(hProc);
	return 0;
}