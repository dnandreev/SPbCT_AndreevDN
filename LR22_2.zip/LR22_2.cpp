#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h>
#include <iostream>
#include <fstream>
using std::cout;
int VAR = 1;
int main(){
    pid_t pid = fork();
    std::ofstream out("Output_processes.txt");
    if(pid < 0){
        cout<< " Fork error ";
    }
    else if (pid == 0){
        cout << " Child process ID: " << getpid() << "\n Parent process ID: " << getppid() << "\n";
    }
    out << "Child process ID: " << getpid() <<"\n" << " Parent process ID: " << getppid();
}