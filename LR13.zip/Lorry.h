#pragma once
#include "Car.h"

class Lorry : public Car {
protected:
	int gruz;

public:
	Lorry(void);
	~Lorry(void);
	Lorry(string, int, int, int);

	Lorry(const Lorry&);

	void Set_Gruz(int);

	Lorry& operator=(const Lorry&);

	friend istream& operator>>(istream& in, Lorry& l);
	friend ostream& operator<<(ostream& out, const Lorry& l);
};