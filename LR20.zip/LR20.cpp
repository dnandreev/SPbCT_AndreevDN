#define LR20DLL_EXPORTS
#include "LR20.h"
#define _USE_MATH_DEFINES
#include <cmath>

double TrianglePerimeter(double s1, double a1, double a2) {
	if ((a1 + a2 >= M_PI) || (s1 == 0))
		return 0;
	else {
		double a3 = M_PI - a1 - a2;
		double s2 = s1 * sin(a2) / sin(a3);
		double s3 = s1 * sin(a1) / sin(a3);
		return s1 + s2 + s3;
	}
}

double TriangleSquare(double s1, double a1, double a2) {
	if ((a1 + a2 >= M_PI) || (s1 == 0))
		return 0;
	else {
		double a3 = M_PI - a1 - a2;
		double s2 = s1 * sin(a2) / sin(a3);
		double s3 = s1 * sin(a1) / sin(a3);
		double p = (s1 + s2 + s3) / 2;
		return sqrt(p * (p - s1) * (p - s2) * (p - s3));
	}
}